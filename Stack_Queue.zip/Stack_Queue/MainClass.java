package Stack_Queue;

//Main method for Task 2 
public class MainClass {
    public static void main(String a[]) {
        // String str = "10 + 20 * 2";
        // String str = "foo / 30 + 7";
        String str = "2 + 1";

        // System.out.println(ArithmeticOperation.solution(str2));
        System.out.println("Solution: " + ArithmeticOperation.solution(str));
    }

}
