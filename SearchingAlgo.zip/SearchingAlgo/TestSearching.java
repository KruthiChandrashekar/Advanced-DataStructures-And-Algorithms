package SearchingAlgo;

public class TestSearching {
    public static void main(String args[]) { // main method

        Searching search = new Searching();

        int[] nums = { 4, 9, 10, 13, 17, 17, 19, 21 }; // input
        // int[] nums = { 1, 2, 3, 4, 5, 6, 7, 8 };
        // int[] nums = { 1, 1, 1, 1, 1 };
        // int[] nums = {};

        int target = 17; // input
        // int target = 1;
        // int target = 6;

        int[] result = search.search(nums, target);
        System.out.println("First: " + result[0] + "\nLast: " + result[1]);

    }

}
